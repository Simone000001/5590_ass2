Census Residential Data Pack - 2011 - Local Authority District Geodata Pack: Leeds (E08000035)


+ Abstract
This geodata pack provides the Census Residential Data Pack for the year 2011 covering the Local Authority District: Leeds (E08000035)


+ Contents
	 - readme.txt: Information about the CDRC Geodata pack
	 - metadata.xml: Metadata
	 - tables: Folder containing the csv files
	 - shapefiles: Folder containing the shapefiles


+ Citation and Copyright
The following attribution statements must be used to acknowledge copyright and source in use of these datasets:
Data provided by the ESRC Consumer Data Research Centre;
Contains National Statistics data Crown copyright and database right;
Contains Ordnance Survey data Crown copyright and database right


+ Funding
Funded by: Economic and Social Research Council 


+ Other Information
Areas that contained no information in the original dataset, are marked with NA in the csv files and NULL in the shapefiles.
